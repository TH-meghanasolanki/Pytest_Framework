import pytest
from selenium import webdriver
from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
from PageObject.signup_module import SignupPage

def test_signup_link (driver):
  
    signuplink = SignupPage(driver)
    signuplink.driver.find_element(*signuplink.signup_link).click()
    
'''from PageObject.signup_module import SignupPage

def test_signup_link (driver):
  
    signuplink = SignupPage(driver)
    signuplink.driver.find_element(*signuplink.signup_link).click()
    
    alert = driver.switch_to.alert
    response_message = alert.text
    alert.accept()  # Close the alert

    return response_message

def test_signup_success(driver):
    signuplink = SignupPage(driver)
    username = "MeghanaSolanki"
    password = "Test@123"

    response = test_signup_link(driver)  # Call helper function
    assert response == "This user already exist."  # Validate success message


def test_signup_without_UN(driver):
    username = ""
    password = "Test@1234"

    response = test_signup_link(driver)
    assert response == "Please fill out Username and Password."


def test_signup_without_PW(driver):
    username = "MeghanaSolanki"
    password = ""

    response = test_signup_link(driver)
    assert response == "Please fill out Username and Password."


def test_signup_duplicate(driver):
    username = "MeghanaSolanki"  # Reusing the same username
    password = "Test@1234"

    response = test_signup_link(driver)
    assert response == "This user already exist."'''
    

def handle_alert(driver):
    """Helper function to handle alerts and return their message."""
    time.sleep(2)  # Wait for alert to appear
    alert = driver.switch_to.alert
    response_message = alert.text
    alert.accept()
    return response_message

def test_signup_success(driver):
    """Test signup with a valid username and password."""
    signuppage = SignupPage(driver)
    signuppage.sign_up("MeghanaSolanki", "Test@123")
    
    response = handle_alert(driver)
    assert response == "Sign up successful."

def test_signup_without_UN(driver):
    """Test signup without a username."""
    signuppage = SignupPage(driver)
    signuppage.sign_up("", "Test@1234")
    
    response = handle_alert(driver)
    assert response == "Please fill out Username and Password."

def test_signup_without_PW(driver):
    """Test signup without a password."""
    signuppage = SignupPage(driver)
    signuppage.sign_up("MeghanaSolanki", "")
    
    response = handle_alert(driver)
    assert response == "Please fill out Username and Password."

def test_signup_duplicate(driver):
    """Test signup with a duplicate username."""
    signuppage = SignupPage(driver)
    signuppage.sign_up("MeghanaSolanki", "Test@1234")
    
    response = handle_alert(driver)
    assert response == "This user already exist."